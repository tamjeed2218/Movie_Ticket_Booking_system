<?php
include '../../includes/configdb.php';
include '../../includes/header.php';
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Users List</h3>
        <a href="add.php" class="btn btn-primary">+ Add User</a>
    </div>

    <?php
    // Alert messages
    if (isset($_GET['msg'])) {
        $msg = htmlspecialchars($_GET['msg']);
        $alertClass = isset($_GET['type']) && $_GET['type'] === 'error' ? 'alert-danger' : 'alert-success';
        echo "<div class='alert $alertClass alert-dismissible fade show' role='alert'>
                $msg
                <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
              </div>";
    }
    ?>

    <div class="table-responsive">
        <table class="table table-striped table-bordered align-middle">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Age</th>
                    <th>Role</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = "SELECT u.user_id, u.name, u.email, u.age, r.role_name
                          FROM users u
                          LEFT JOIN roles r ON u.role_id = r.role_id
                          ORDER BY u.user_id ASC";
                $result = mysqli_query($conn, $query);
                $count = 1;

                if ($result && mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        ?>
                        <tr>
                            <td><?= $count++; ?></td>
                            <td><?= htmlspecialchars($row['name']); ?></td>
                            <td><?= htmlspecialchars($row['email']); ?></td>
                            <td><?= intval($row['age']); ?></td>
                            <td><?= htmlspecialchars($row['role_name']); ?></td>
                            <td>
                                <div class="btn-group" role="group">
                                    <a href="view.php?id=<?= $row['user_id']; ?>" class="btn btn-info btn-sm" title="View User">
                                        <i class="fa fa-eye"></i>
                                    </a>
                                    <a href="edit.php?id=<?= $row['user_id']; ?>" class="btn btn-warning btn-sm" title="Edit User">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <form action="delete.php" method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this user?');">
                                        <input type="hidden" name="user_id" value="<?= $row['user_id']; ?>">
                                        <button type="submit" class="btn btn-danger btn-sm" title="Delete User">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php
                    }
                } else {
                    echo '<tr><td colspan="6" class="text-center">No users found.</td></tr>';
                }
                ?>
            </tbody>
        </table>
    </div>

    <a href="dashboard.php" class="btn btn-secondary mt-3">Go Back</a>
</div>

<?php
include '../../includes/footer.php';
?>
